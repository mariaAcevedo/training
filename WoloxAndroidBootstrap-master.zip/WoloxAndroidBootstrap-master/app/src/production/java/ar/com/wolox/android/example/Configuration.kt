package ar.com.wolox.android.example

internal class Configuration : BaseConfiguration() {
    companion object {
        const val API_ENDPOINT = "http://api.wolox.com.ar"
    }
}
