package ar.com.wolox.android.example.model

data class ViewPagerModel(val name: String)
