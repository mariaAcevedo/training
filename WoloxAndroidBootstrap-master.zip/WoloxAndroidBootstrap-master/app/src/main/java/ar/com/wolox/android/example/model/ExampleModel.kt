package ar.com.wolox.android.example.model

data class ExampleModel(val someNumber: Int)