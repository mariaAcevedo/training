package ar.com.wolox.android.example.ui.viewpager.random

interface IRandomView {

    fun setUsername(username: String)

    fun onRandomNumberUpdate(someNumber: Int)
}
