package ar.com.wolox.android.example.model

data class Post(val title: String, val body: String)
