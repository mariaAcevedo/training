package ar.com.wolox.android.example.ui.example

interface IExampleView {

    fun onUsernameSaved()
}
